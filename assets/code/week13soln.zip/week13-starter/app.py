# required imports
# the sqlite3 library allows us to communicate with the sqlite database
import sqlite3
# we are adding the import 'g' which will be used for the database
from flask import Flask, render_template, redirect, url_for, request, g

# the database file we are going to communicate with
DATABASE = './database.db'

# connects to the database
def get_db():
    # if there is a database, use it
    db = getattr(g, '_database', None)
    if db is None:
        # otherwise, create a database to use
        db = g._database = sqlite3.connect(DATABASE)
    return db

# converts the tuples from get_db() into dictionaries
# (don't worry if you don't understand this code)
def make_dicts(cursor, row):
    return dict((cursor.description[idx][0], value)
                for idx, value in enumerate(row))

# given a query, executes and returns the result
# (don't worry if you don't understand this code)
def query_db(query, args=(), one=False):
    cur = get_db().execute(query, args)
    rv = cur.fetchall()
    cur.close()
    return (rv[0] if rv else None) if one else rv

# tells Flask that "this" is the current running app
app = Flask(__name__)

# this function gets called when the Flask app shuts down
# tears down the database connection
@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        # close the database if we are connected to it
        db.close()

# setup the default route
# this is the page the site will load by default (i.e. like the home page)
@app.route('/')
def root():
    # get the database
    db = get_db()
    # apply make_dicts (to change the result from a tuple to a dictioanry -- easier to work with)
    db.row_factory = make_dicts

    employees = []
    # query for all employees
    for employee in query_db('select * from employees'):
        employees.append(employee)
    # close the database after using it (this is important)
    db.close()

    # tells Flask to render the HTML page called index.html    
    return render_template('index.html', employee=employees)

# add a comment for an employee
@app.route('/comment', methods=['POST'])
def add_comment():
    db = get_db()
    db.row_factory = make_dicts
    cur = db.cursor()

    employee_name = request.form['employee-name']
    author_name = request.form['author']
    comment = request.form['comment']

    employee = query_db('select * from employees where firstname = ?', [employee_name], one=True)

    cur.execute('insert into comments (author, comment, employee_id) values (?, ?, ?)', [author_name, comment, employee['id']])
    db.commit()
    cur.close()

    return redirect(url_for('root'))

# get an employee by name
@app.route('/employee')
def get_employee():
    db = get_db()
    db.row_factory = make_dicts

    employee_name = request.args.get('name')

    # get the employee object
    employee = query_db('select * from employees where firstname = ?', [employee_name], one=True)
    # get all comments
    comments = query_db('select * from comments where employee_id = ?', [employee['id']])
    db.close()
    
    # render the result
    return render_template('employee.html', employee_name=employee_name, employee_feedback=comments)

# add a new employee
@app.route('/new-employee', methods=['POST'])
def new_employee():
    db = get_db()
    db.row_factory = make_dicts
    cur = db.cursor()

    new_employee = request.form

    cur.execute('insert into employees (firstname, lastname, position, salary) values (?, ?, ?, ?)', [
        new_employee['firstname'],
        new_employee['lastname'],
        new_employee['position'],
        new_employee['salary']])
    db.commit()
    cur.close()

    return redirect(url_for('root'))

# run the app when app.py is run
if __name__ == '__main__':
    app.run(debug=True)