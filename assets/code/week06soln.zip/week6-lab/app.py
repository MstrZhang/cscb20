# required imports; you may add more in the future; currently, we will only use render_template
# NOTE: i'm using url_for to include the CSS file in index.html; it's not necessary to use for this lab
from flask import Flask, render_template, request, url_for

# tells Flask that "this" is the current running app
app = Flask(__name__)

todo_list = []

# setup the default route
# this is the page the site will load by default (i.e. like the home page)
@app.route('/')
def root():
    # tells Flask to render the HTML page called index.html
    return render_template('index.html', todo_list=todo_list)

@app.route('/add')
def add_todo():
    global todo_list
    todo_list.append(request.args.get('todo-input'))
    return render_template('index.html', todo_list=todo_list)

# run the app when app.py is run
if __name__ == '__main__':
    # we set debug=True so you don't have to restart the app everything you make changes
    # just refresh the browser after each change
    app.run(debug=True)
