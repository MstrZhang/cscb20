# required imports
# the sqlite3 library allows us to communicate with the sqlite database
import sqlite3
# we are adding the import 'g' which will be used for the database
from flask import Flask, render_template, request, g

# the database file we are going to communicate with
DATABASE = './database.db'

# connects to the database
def get_db():
    # if there is a database, use it
    db = getattr(g, '_database', None)
    if db is None:
        # otherwise, create a database to use
        db = g._database = sqlite3.connect(DATABASE)
    return db

# converts the tuples from get_db() into dictionaries
# (don't worry if you don't understand this code)
def make_dicts(cursor, row):
    return dict((cursor.description[idx][0], value)
                for idx, value in enumerate(row))

# given a query, executes and returns the result
# (don't worry if you don't understand this code)
def query_db(query, args=(), one=False):
    cur = get_db().execute(query, args)
    rv = cur.fetchall()
    cur.close()
    return (rv[0] if rv else None) if one else rv

# tells Flask that "this" is the current running app
app = Flask(__name__)

# this function gets called when the Flask app shuts down
# tears down the database connection
@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        # close the database if we are connected to it
        db.close()

# setup the default route
# this is the page the site will load by default (i.e. like the home page)
@app.route('/')
def root():
    # TODO: complete this section
    #   - display all of the employees that work at Dunder Miffiln
    #   - pass in the appropriate value to render_template()

    return render_template('index.html')

@app.route('/employee')
def get_employee():
    # TODO: complete this section
    #   - display all the information of the employee with the given name
    #   - pass in the appropriate value to render_template()
    #   - HINT: use request.args.get('NAME_OF_PARAM') to get the user's input value

    return render_template('index.html')

# run the app when app.py is run
if __name__ == '__main__':
    app.run(debug=True)