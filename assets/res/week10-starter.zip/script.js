// returns a random number between 0 and "max" (exclusive)
function getRandomInt(max) {
    return Math.floor(Math.random() * Math.floor(max));
}

// determine if the game is a win, loss, or tie
// this function should not return anything, edit the HTML accordingly
function play(action) {
    // keep track of what the computer and player intend to do
    let computerAction = '';
    let playerAction = action;

    // keep track of the player, computer, and end message
    let playerMessage = '';
    let computerMessage = '';
    let endMessage = '';

    // randomly assign an action to the computer
    // TODO: complete this code


    // assign the player's and computer's message accordingly
    // TODO: complete this code


    // handle who wins or loses
    // update the end message accordingly
    // TODO: complete this code


    // update the game log
    // TODO: complete this code

    // get the actual element
    // create the list items
    // add the list items to the list in the HTML
}